﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.ComponentModel;
using System.Drawing;

using System.Text;

using System.Data.SqlClient;


public partial class _Default : System.Web.UI.Page 
{

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    //insert
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox2.Text != "" && TextBox3.Text != "" && TextBox4.Text != "")
        {
            string conn = "";

            conn = ConfigurationManager.ConnectionStrings["conn"].ToString();

            SqlConnection objsqlconn = new SqlConnection(conn);

            objsqlconn.Open();

            SqlCommand objcmd = new SqlCommand("Insert into Record(Name,Address,City) Values('" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "')", objsqlconn);

            objcmd.ExecuteNonQuery();


            Response.Redirect("Default.aspx");

        }
        else
        {
           
                Label5.Text = "Data not filled";

          

            }
    


    }

    //update
    protected void Button2_Click(object sender, EventArgs e)
    {
      if (TextBox2.Text != "" && TextBox3.Text != "" && TextBox4.Text != "")
        {  
        string conn = "";

        conn = ConfigurationManager.ConnectionStrings["conn"].ToString();
        SqlConnection objsqlconn = new SqlConnection(conn);

        objsqlconn.Open();

        SqlCommand objcmd = new SqlCommand("Update Record set Name='" + TextBox2.Text + "',Address='" + TextBox3.Text + "',City='" + TextBox4.Text + "' where Name='" + TextBox2.Text + "'", objsqlconn);
      //  TextBox5.Text = "Record updated successfully";


        objcmd.ExecuteNonQuery();

       Response.Redirect("Default.aspx");

        }
        else
        {
           
            Label5.Text = "Data not filled";

        }
        
      
    }


    //delete
    protected void Button3_Click(object sender, EventArgs e)
    {
        
string conn = "";

conn = ConfigurationManager.ConnectionStrings["Conn"].ToString();

SqlConnection objsqlconn = new SqlConnection(conn);

objsqlconn.Open();

SqlCommand objcmd = new SqlCommand("Delete from Record Where Name='" + TextBox2.Text + "'", objsqlconn);

objcmd.ExecuteNonQuery();
Response.Redirect("Default.aspx");


    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
   
}